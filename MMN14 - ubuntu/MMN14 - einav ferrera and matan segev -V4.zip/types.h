#ifndef TYPES_H
#define TYPES_H

#define true 1
#define false 0

typedef int bool;

#endif 

